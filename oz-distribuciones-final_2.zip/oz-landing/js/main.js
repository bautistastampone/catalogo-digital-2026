'use strict';

const WA_NUMBER = '5493834932557';
const WA_BASE   = `https://wa.me/${WA_NUMBER}?text=`;
const STORAGE_PRICES = 'oz_price_overrides';
const STORAGE_IMAGES = 'oz_image_overrides';
const PER_PAGE = 16;

const BUCKETS = {
  todos: null,
  elec:  ['0','1','2','3','4','5','6','10','11','12','13','17'],
  ilum:  ['14','15','16','20','21','22'],
  pint:  ['7','8','9'],
  mat:   ['18','19','23']
};

const EMOJIS = {
  '0':'🔐','1':'⚡','2':'⚡','3':'📦','4':'🔌','5':'🔌','6':'🔌',
  '7':'🖌️','8':'🎨','9':'🎨','10':'🔌','11':'📏','12':'💡','13':'🔌',
  '14':'💡','15':'💡','16':'💡','17':'📦','18':'🔧','19':'🧽',
  '20':'💡','21':'💡','22':'🔆','23':'📦'
};

let ALL = [], CATS = [];
let activeBucket = 'todos';
let searchQuery  = '';
let editMode     = false;
let priceOverrides = {};
let imageOverrides = {};

// ── Boot ─────────────────────────────────
async function boot() {
  loadOverrides();
  try {
    // Try data/ subfolder first, fallback to root
    let r = await fetch('./data/products.json');
    if (!r.ok) r = await fetch('./products.json');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const d = await r.json();
    ALL  = d.products   || [];
    CATS = d.categories || [];
  } catch (e) {
    console.error('Error loading products:', e);
    const grid = document.getElementById('prod-grid');
    if (grid) grid.innerHTML =
      `<div style="grid-column:1/-1;padding:48px;text-align:center;color:#e85d04">
        <p style="font-size:15px;margin-bottom:14px">⚠ No se pudieron cargar los productos.</p>
        <a href="${WA_BASE + enc('Hola! Quiero consultar por productos de OZ Distribuciones.')}"
           target="_blank" rel="noopener"
           style="display:inline-flex;align-items:center;gap:8px;padding:11px 22px;background:#25d366;color:white;border-radius:8px;font-weight:700;font-size:13px;text-decoration:none">
          Consultar por WhatsApp
        </a>
      </div>`;
    return;
  }
  renderCatalog();
  updateBadgeCount();
}

// ── LocalStorage ─────────────────────────
function loadOverrides() {
  try { priceOverrides = JSON.parse(localStorage.getItem(STORAGE_PRICES) || '{}'); } catch(_) { priceOverrides = {}; }
  try { imageOverrides = JSON.parse(localStorage.getItem(STORAGE_IMAGES) || '{}'); } catch(_) { imageOverrides = {}; }
}
function saveOverrides() {
  try { localStorage.setItem(STORAGE_PRICES, JSON.stringify(priceOverrides)); } catch(_) {}
  try {
    // Images can be large — guard against QuotaExceededError
    localStorage.setItem(STORAGE_IMAGES, JSON.stringify(imageOverrides));
  } catch(e) {
    console.warn('localStorage full, images not saved:', e.message);
  }
}

// ── Filter ───────────────────────────────
function getFiltered() {
  const ids = BUCKETS[activeBucket];
  const q   = searchQuery.toLowerCase();
  return ALL.filter(p => {
    if (ids && !ids.includes(p.categoryId)) return false;
    if (q && !String(p.sku).toLowerCase().includes(q) && !p.name.toLowerCase().includes(q)) return false;
    return true;
  });
}

// ── Render ───────────────────────────────
function renderCatalog() {
  const filtered = getFiltered();
  const display  = filtered.slice(0, PER_PAGE);
  const grid     = document.getElementById('prod-grid');
  const info     = document.getElementById('prod-info');

  if (info) {
    const t = filtered.length;
    info.textContent = `Mostrando ${Math.min(display.length, t)} de ${t.toLocaleString('es-AR')} producto${t !== 1 ? 's' : ''}`;
  }

  if (!display.length) {
    if (grid) grid.innerHTML = emptyState();
    return;
  }
  if (grid) grid.innerHTML = display.map(prodCard).join('');

  // Bind image file inputs after render
  if (grid) {
    grid.querySelectorAll('.img-file-input').forEach(input => {
      input.addEventListener('change', handleImageUpload);
    });
  }
}

function emptyState() {
  const q = searchQuery;
  const waUrl = WA_BASE + enc(`Hola! Busco el producto: ${q}`);
  return `<div style="grid-column:1/-1;text-align:center;padding:56px 20px;color:#717171">
    <div style="font-size:40px;margin-bottom:14px">🔍</div>
    <p style="font-size:15px;margin-bottom:16px">Sin resultados${q ? ` para "<strong>${escHtml(q)}</strong>"` : ''}</p>
    <a href="${waUrl}" target="_blank" rel="noopener"
       style="display:inline-flex;align-items:center;gap:8px;padding:11px 22px;background:#25d366;color:white;border-radius:8px;font-weight:700;font-size:13px;text-decoration:none">
      <svg width="16" height="16" viewBox="0 0 24 24" style="fill:white;flex-shrink:0"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM11.999 2C6.477 2 2 6.477 2 12c0 1.89.52 3.656 1.427 5.168L2 22l4.946-1.404A9.956 9.956 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2zm0 18a7.946 7.946 0 0 1-4.051-1.105l-.29-.173-3.018.857.862-3.01-.19-.31A7.944 7.944 0 0 1 4 12c0-4.411 3.589-8 8-8s8 3.589 8 8-3.589 8-8 8z"/></svg>
      Consultar por WhatsApp
    </a>
  </div>`;
}

function prodCard(p) {
  const price     = priceOverrides[p.sku] !== undefined ? priceOverrides[p.sku] : p.price;
  const imgSrc    = imageOverrides[p.sku] || p.image || '';
  const isEdited  = priceOverrides[p.sku] !== undefined || imageOverrides[p.sku] !== undefined;
  const emoji     = EMOJIS[p.categoryId] || '📦';
  const label     = p.priceLabel || p.currency || '';
  const editCls   = editMode ? ' edit-mode' : '';
  const editedCls = isEdited ? ' is-edited' : '';

  // Format price for display
  const priceDisplay = price !== null && price !== undefined
    ? fmtPrice(price, p.currency)
    : null;

  // WA message with product name + price (required format)
  const priceTxt = priceDisplay
    ? (p.currency === 'USD' ? `USD ${priceDisplay}` : `$${priceDisplay}`)
    : 'Consultar';
  const waText = `Hola, quiero consultar por este producto:\nProducto: ${p.name}\nSKU: ${p.sku}\nPrecio: ${priceTxt}`;
  const waUrl  = WA_BASE + enc(waText);
  const consultText = `Hola! Quiero cotizar:\nProducto: ${p.name}\nCódigo: ${p.sku}`;
  const consultUrl  = WA_BASE + enc(consultText);

  const imgHtml = imgSrc
    ? `<img src="${escHtml(imgSrc)}" alt="${escHtml(p.name)}" loading="lazy">`
    : `<span class="prod-img-emoji">${emoji}</span>`;

  const priceHtml = editMode
    ? `<input class="prod-price-input" type="number" min="0" step="0.01"
         value="${price !== null && price !== undefined ? Number(price) : ''}"
         placeholder="—"
         data-sku="${escHtml(String(p.sku))}"
         onchange="updatePrice(this)"
         onclick="this.select()">`
    : priceDisplay !== null
      ? `<span class="prod-price"><span class="cur">${escHtml(label)}&nbsp;</span>${priceDisplay}</span>`
      : `<span class="prod-price-null">Consultar precio</span>`;

  return `<div class="prod-card${editCls}${editedCls}" data-sku="${escHtml(String(p.sku))}">
    <div class="edited-dot"></div>
    <div class="prod-img-wrap">
      ${imgHtml}
      <span class="prod-img-badge">EN STOCK</span>
      <button class="prod-img-edit" onclick="triggerImgUpload('${escHtml(String(p.sku))}')" title="Cambiar imagen">
        <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        Cambiar
      </button>
      <input class="prod-img-input img-file-input" type="file" accept="image/*" data-sku="${escHtml(String(p.sku))}">
    </div>
    <div class="prod-body">
      <span class="prod-sku">${escHtml(String(p.sku))}</span>
      <div class="prod-name" title="${escHtml(p.name)}">${escHtml(p.name)}</div>
      <div class="prod-cat">${escHtml(p.category || '')}</div>
      <div class="prod-price-row">${priceHtml}</div>
      <div class="prod-actions">
        <a href="${consultUrl}" class="prod-btn prod-btn--dark" target="_blank" rel="noopener">
          <svg viewBox="0 0 24 24" stroke="currentColor" fill="none" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          Consultar
        </a>
        <a href="${waUrl}" class="prod-btn prod-btn--wa" target="_blank" rel="noopener">
          <svg viewBox="0 0 24 24" style="fill:white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM11.999 2C6.477 2 2 6.477 2 12c0 1.89.52 3.656 1.427 5.168L2 22l4.946-1.404A9.956 9.956 0 0 0 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2zm0 18a7.946 7.946 0 0 1-4.051-1.105l-.29-.173-3.018.857.862-3.01-.19-.31A7.944 7.944 0 0 1 4 12c0-4.411 3.589-8 8-8s8 3.589 8 8-3.589 8-8 8z"/></svg>
          WA
        </a>
      </div>
    </div>
  </div>`;
}

// ── Filter actions ───────────────────────
function setBucket(bucket, btn) {
  activeBucket = bucket;
  searchQuery  = '';
  const inp = document.getElementById('prod-search');
  if (inp) inp.value = '';
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('is-active'));
  if (btn) btn.classList.add('is-active');
  renderCatalog();
}

function onSearch(val) {
  searchQuery = (val || '').trim();
  renderCatalog();
}

// ── Edit mode ────────────────────────────
function toggleEdit() {
  editMode = !editMode;
  const btn    = document.getElementById('edit-toggle');
  const banner = document.getElementById('edit-banner');
  const lbl    = btn ? btn.querySelector('span:last-child') : null;
  const icon   = document.getElementById('edit-icon');

  if (btn)    btn.classList.toggle('is-active', editMode);
  if (lbl)    lbl.textContent = editMode ? 'Salir de edición' : 'Editar precios';
  if (banner) banner.classList.toggle('is-visible', editMode);
  if (icon) {
    icon.innerHTML = editMode
      ? '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>'
      : '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>';
  }
  renderCatalog();
}

function updatePrice(input) {
  const sku = String(input.dataset.sku);
  const val = parseFloat(String(input.value).replace(',', '.'));
  if (!isNaN(val) && val >= 0) {
    priceOverrides[sku] = val;
  } else if (input.value === '') {
    delete priceOverrides[sku];
  }
  saveOverrides();
  markEdited(sku);
  updateBadgeCount();
}

function markEdited(sku) {
  try {
    const card = document.querySelector(`.prod-card[data-sku="${CSS.escape(String(sku))}"]`);
    if (!card) return;
    const edited = priceOverrides[sku] !== undefined || imageOverrides[sku] !== undefined;
    card.classList.toggle('is-edited', edited);
  } catch(e) { /* CSS.escape might fail on some chars */ }
}

function saveAll() {
  saveOverrides();
  showToast('✅ Cambios guardados en el navegador');
  updateBadgeCount();
}

function restoreAll() {
  if (!confirm('¿Restaurar todos los precios e imágenes al original del catálogo?\nEsta acción no se puede deshacer.')) return;
  priceOverrides = {};
  imageOverrides = {};
  saveOverrides();
  renderCatalog();
  updateBadgeCount();
  showToast('↩ Todo restaurado al original');
}

function updateBadgeCount() {
  const cnt = Object.keys(priceOverrides).length + Object.keys(imageOverrides).length;
  const el  = document.getElementById('edited-count');
  if (el) el.textContent = cnt > 0 ? ` · ${cnt} editado${cnt !== 1 ? 's' : ''}` : '';
}

// ── Image upload ─────────────────────────
function triggerImgUpload(sku) {
  try {
    const card  = document.querySelector(`.prod-card[data-sku="${CSS.escape(String(sku))}"]`);
    const input = card ? card.querySelector('.img-file-input') : null;
    if (input) input.click();
  } catch(e) { console.warn('triggerImgUpload error:', e); }
}

function handleImageUpload(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const sku    = String(e.target.dataset.sku);
  const reader = new FileReader();
  reader.onload = ev => {
    const dataURL = ev.target.result;
    imageOverrides[sku] = dataURL;
    saveOverrides();
    markEdited(sku);
    updateBadgeCount();
    // Update preview inline without re-render
    try {
      const card = document.querySelector(`.prod-card[data-sku="${CSS.escape(sku)}"]`);
      if (card) {
        const wrap  = card.querySelector('.prod-img-wrap');
        const emoji = wrap.querySelector('.prod-img-emoji');
        if (emoji) emoji.remove();
        let img = wrap.querySelector('img');
        if (!img) {
          img = document.createElement('img');
          img.alt = sku;
          img.style.width  = '100%';
          img.style.height = '100%';
          img.style.objectFit = 'cover';
          wrap.insertBefore(img, wrap.firstChild);
        }
        img.src = dataURL;
        card.classList.add('is-edited');
      }
    } catch(err) { console.warn('img preview error:', err); }
    showToast('🖼 Imagen actualizada');
  };
  reader.readAsDataURL(file);
}

// ── Price formatter ──────────────────────
function fmtPrice(v, cur) {
  const n = Number(v);
  if (isNaN(n)) return '—';
  return n.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ── Toast ────────────────────────────────
let toastTimer;
function showToast(msg, ms = 2800) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('is-visible'), ms);
}

// ── Navbar scroll ────────────────────────
window.addEventListener('scroll', () => {
  const nb = document.getElementById('navbar');
  if (nb) nb.classList.toggle('is-scrolled', window.scrollY > 20);
}, { passive: true });

// ── Mobile menu ──────────────────────────
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-nav');
  const ham  = document.getElementById('hamburger');
  if (!menu) return;
  const open = menu.classList.toggle('is-open');
  if (ham) ham.classList.toggle('is-open', open);
}
function closeMobileMenu() {
  const menu = document.getElementById('mobile-nav');
  const ham  = document.getElementById('hamburger');
  if (menu) menu.classList.remove('is-open');
  if (ham)  ham.classList.remove('is-open');
}

// ── FAQ ──────────────────────────────────
function toggleFaq(btn) {
  const ans    = btn.nextElementSibling;
  const isOpen = btn.classList.contains('is-open');
  document.querySelectorAll('.faq-q.is-open').forEach(q => {
    q.classList.remove('is-open');
    if (q.nextElementSibling) q.nextElementSibling.classList.remove('is-open');
  });
  if (!isOpen) {
    btn.classList.add('is-open');
    if (ans) ans.classList.add('is-open');
  }
}

// ── Search debounce ──────────────────────
let searchTimer;
function debounceSearch(val) {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => onSearch(val), 220);
}

// ── Utils ────────────────────────────────
function escHtml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
function enc(s) { return encodeURIComponent(String(s || '')); }

// ── Global exports ───────────────────────
window.setBucket        = setBucket;
window.debounceSearch   = debounceSearch;
window.toggleEdit       = toggleEdit;
window.updatePrice      = updatePrice;
window.saveAll          = saveAll;
window.restoreAll       = restoreAll;
window.triggerImgUpload = triggerImgUpload;
window.toggleFaq        = toggleFaq;
window.toggleMobileMenu = toggleMobileMenu;
window.closeMobileMenu  = closeMobileMenu;
window.filterCatalog    = function(bucket) {
  // Called from category cards
  const btn = document.querySelector(`.filter-tab[data-bucket="${bucket}"]`);
  setBucket(bucket, btn);
  const sec = document.getElementById('catalogo');
  if (sec) sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
};

// ── Init ─────────────────────────────────
document.addEventListener('DOMContentLoaded', boot);
